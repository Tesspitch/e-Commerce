<template>
  <div class="bw-container">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3>สินค้า</h3>
      <router-link class="btn btn-outline-primary" to="/kpi">ดู KPI</router-link>
    </div>

    <div class="bw-grid">
      <SidebarFilters :model-value="filters" @apply="applyFilters" />

      <div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-xl-4 g-3">
          <div class="col" v-for="p in sortedAndFiltered" :key="p.id">
            <ProductCard :item="p" @add="addToCart" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useProductsStore } from '@/stores/products'
import { useCartStore } from '@/stores/cart'
import SidebarFilters from '@/components/SidebarFilters.vue'
import ProductCard from '@/components/ProductCard.vue'

const products = useProductsStore()
const cart = useCartStore()
const filters = ref({ category:'', brand:'', minPrice:0, maxPrice:999999, sort:'' })

onMounted(()=>{ products.fetch() })

const applyFilters = (f)=>{ filters.value = f }
const addToCart = (p)=> cart.add(p, 1)

const sortedAndFiltered = computed(()=>{
  const list = (products.list||[]).filter(p=>{
    const okCat = !filters.value.category || p.category === filters.value.category
    const okBrand = !filters.value.brand || p.brand === filters.value.brand
    const price = Number(p.price)||0
    const okPrice = price >= (filters.value.minPrice ?? 0) && price <= (filters.value.maxPrice ?? Infinity)
    return okCat && okBrand && okPrice
  })
  if(filters.value.sort==='price-asc') list.sort((a,b)=> (Number(a.price)||0)-(Number(b.price)||0))
  if(filters.value.sort==='price-desc') list.sort((a,b)=> (Number(b.price)||0)-(Number(a.price)||0))
  return list
})
</script>
