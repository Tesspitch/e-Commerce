import axios from 'axios'

const api = axios.create({ baseURL: import.meta.env.VITE_API_BASE || 'http://54.169.154.143:3452' })

export const getProducts = () => api.get('/ecommerce-product')
export const getProductById = (id) => api.get(`/ecommerce-product/${id}`)

export const getOrders = () => api.get('/ecommerce-orders')
export const getOrderById = (id) => api.get(`/ecommerce-orders/${id}`)
export const createOrder = (payload) => api.post('/ecommerce-orders', payload)

export default api
