import { defineStore } from 'pinia'
import { getProducts } from '@/services/api'

export const useProductsStore = defineStore('products', {
  state: () => ({
    list: [],
    loading: false,
    error: null,
  }),
  getters: {
    categories: (s) => [...new Set(s.list.map(p => p.category).filter(Boolean))],
    brands: (s) => [...new Set(s.list.map(p => p.brand).filter(Boolean))],
    priceRange: (s) => {
      if(!s.list.length) return [0,0]
      const prices = s.list.map(p => Number(p.price)||0)
      return [Math.min(...prices), Math.max(...prices)]
    },
  },
  actions: {
    async fetch(){
      try{ this.loading = true; this.error = null
        const { data } = await getProducts()
        this.list = Array.isArray(data) ? data : []
      }catch(err){ this.error = err?.message || 'Fetch products failed' }
      finally{ this.loading = false }
    }
  }
})
