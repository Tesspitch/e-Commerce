import { defineStore } from 'pinia'
import { getOrders, getOrderById, createOrder } from '@/services/api'

export const useOrdersStore = defineStore('orders', {
  state: () => ({ list: [], loading:false, error:null }),
  getters: {
    kpi: (s) => {
      const totalOrders = s.list.length
      const totalRevenue = s.list.reduce((a,o)=> a + (Number(o.total)||0), 0)
      const avgOrderValue = totalOrders? (totalRevenue/totalOrders) : 0
      const topCategory = (()=>{
        const map = {}
        s.list.forEach(o=>{
          ;(o.items||[]).forEach(it=>{ if(it.category){ map[it.category]=(map[it.category]||0)+it.qty } })
        })
        return Object.entries(map).sort((a,b)=>b[1]-a[1])[0]?.[0] || '-'
      })()
      const topBrand = (()=>{
        const map = {}
        s.list.forEach(o=>{
          ;(o.items||[]).forEach(it=>{ if(it.brand){ map[it.brand]=(map[it.brand]||0)+it.qty } })
        })
        return Object.entries(map).sort((a,b)=>b[1]-a[1])[0]?.[0] || '-'
      })()
      return { totalOrders, totalRevenue, avgOrderValue, topCategory, topBrand }
    }
  },
  actions: {
    async fetch(){
      try{ this.loading=true; this.error=null
        const { data } = await getOrders()
        this.list = Array.isArray(data)? data: []
      }catch(err){ this.error = err?.message || 'Fetch orders failed' }
      finally{ this.loading=false }
    },
    async getById(id){
      const { data } = await getOrderById(id)
      return data
    },
    async create(payload){
      const { data } = await createOrder(payload)
      this.list.unshift(data)
      return data
    }
  }
})
